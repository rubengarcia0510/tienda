Installation procedure is described here:
http://dev.virtuemart.net/projects/virtuemart/wiki/Easy_VirtueMart_2_Install_Instructions