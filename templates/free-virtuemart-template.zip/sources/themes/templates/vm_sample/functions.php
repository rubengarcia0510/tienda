<?php

	function tm_border_content_top () {
	
	}

	function tm_border_content_bottom () {
	
	}


	function tm_border_heading ($heading) {
		echo '' . $heading . '';
	}


	function tm_border_inner_content_top () {
	
	}

	function tm_border_inner_content_bottom () {
	
	}


	function tm_border_item_top () {
	
	}

	function tm_border_item_bottom () {
	
	}


	function tm_border_image_top () {
	
	}

	function tm_border_image_bottom () {
	
	}


	function tm_border_links_top () {
	
	}

	function tm_border_links_bottom () {
	
	}
?>