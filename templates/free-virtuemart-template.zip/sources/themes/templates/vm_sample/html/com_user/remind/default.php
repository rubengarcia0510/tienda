<?php defined('_JEXEC') or die; ?>

<?php if ( $this->params->def( 'show_page_title', 1 ) ) : ?>
	<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
		<?php echo $this->escape($this->params->get('page_title')); ?>
	</div>
<?php endif; ?>
<form action="<?php echo JRoute::_( 'index.php?option=com_user&task=remindusername' ); ?>" method="post" class="josForm form-validate">
    <dl class="contentpane">
        <dt> <?php echo JText::_('REMIND_USERNAME_DESCRIPTION'); ?> </dt>
        <dd>
            <table style="width:auto">
                <tr>
                    <td class="description"><label for="email" class="hasTip" title="<?php echo JText::_('REMIND_USERNAME_EMAIL_TIP_TITLE'); ?>::<?php echo JText::_('REMIND_USERNAME_EMAIL_TIP_TEXT'); ?>"><?php echo JText::_('Email Address'); ?>:</label>
                    </td>
                    <td class="input-field"><input id="email" name="email" type="text" class="required validate-email" />
                    </td>
                    <td class="button-field"><button type="submit" class="validate"><?php echo JText::_('Submit'); ?></button></td>
                </tr>
            </table>
        </dd>
    </dl>
    <?php echo JHTML::_( 'form.token' ); ?>
</form>

